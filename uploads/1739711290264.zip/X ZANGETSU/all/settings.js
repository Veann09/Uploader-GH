/*
      ⟅̊༑ ▾ ⌜ メ-𝐅𝐚𝐱𝐳𝐁𝐮𝐠 3.0 ⌟ ▾ ༑̴⟆̊

->  Botz Resmi Dijual Oleh AlwaysFaxz
->   𝙸𝚗𝚟𝚒𝚜𝚒𝚋𝚕𝚎 𝙱𝚞𝚐
->  Credits : 𝚂𝚞𝚋𝚜𝚌𝚛𝚒𝚋𝚎 @faxz.attacker

     ⟅̊༑ ▾ ⌜ メ-𝐅𝐚𝐱𝐳𝐁𝐮𝐠 3.0 ⌟ ▾ ༑̴⟆̊
*/
require("./module")

global.owner = "66942093266" //PAKE NO LU BIAR BISA ADD AKSES
global.namabot = "⟅̊༑ ▾ ⌜ メ-𝐅𝐚𝐱𝐳𝐁𝐮𝐠 4.0 ⌟ ▾ ༑̴⟆̊" //NAMA BOT GANTI
global.nameCreator = "⟅̊༑ ▾ ⌜ 𝐀𝐥𝐰𝐚𝐲𝐬𝐅𝐚𝐱𝐳 ⌟ ▾ ༑̴⟆̊" //NAMA CREATOR GANTI AJA
global.autoJoin = false //NOT CHANGE / JANGAN GANTI
global.antilink = true //NOT CHANGE / JANGAN GANTI
global.versisc = '4.0.0' //NOT CHANGE / JANGAN GANTI
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
// SETTING PELI \\
//======================================
global.imageurl = 'https://files.catbox.moe/yowhfl.jpg' 
global.isLink = 'https://whatsapp.com/channel/0029Vamo6AZ002TD5ECrqv1N' ///GANTI MENGGUNAKAN LINK GC/CH
//======================================
global.linksaluran = ""
global.linkyt = 'https://www.youtube.com/@faxz.attacker'
global.idsaluran = "-"
global.simbol = 'ダ'
global.simbol1 = '×'
global.simbol2 = '★'
global.gsz = '⟅̊༑ ▾ ⌜ 𝐀𝐥𝐰𝐚𝐲𝐬𝐅𝐚𝐱𝐳 ⌟ ▾ ༑̴⟆̊'
global.logic = 'Saya adalah AI yang dirancang untuk membantu mahasiswa dalam pembahasan coding serta pelajaran umum seperti Matematika, Bahasa Indonesia, Bahasa Inggris, Fisika, Kimia, Rekayasa Perangkat Lunak, dan Basis Data dengan penjelasan yang mudah dipahami dan relevan'

//===========================//

global.xchannel = {
	jid: '120363294318768415@newsletter'
	}

//===========================//

global.country = `62`
global.system = {
gmail: `AlwaysFaxz@gmail.com`,
}

//===========================//

global.nick = {
aaa: "‏ ⟅̊༑ ▾ ⌜ 𝐀𝐥𝐰𝐚𝐲𝐬𝐅𝐚𝐱𝐳 メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊", 
sss: " ⟅̊༑ ▾ ⌜ ☠ 𝐀𝐥𝐰𝐚𝐲𝐬𝐅𝐚𝐱𝐳 ☠ ⌟ ▾ ༑̴⟆̤̊" 
}
global.tekspushkon = "" //NOT CHANGE / JANGAN GANTI
global.tekspushkonv2 = "" //NOT CHANGE / JANGAN GANTI
global.packname = "By X-FaxzBug v4.0" //GANTI AJ
global.author = "AlwaysFaxz\n\n\n\n\n\n\n\n\n\n\n\n\n\nmau add favorite bg :v\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" 
global.jumlah = "5" ////NOT CHANGE / JANGAN GANTI

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})